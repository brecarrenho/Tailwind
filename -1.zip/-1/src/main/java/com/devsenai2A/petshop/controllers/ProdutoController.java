package com.devsenai2A.petshop.controllers;

import com.devsenai2A.petshop.entities.Produto;
import com.devsenai2A.petshop.services.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/produtos")
@CrossOrigin("*")
public class ProdutoController {

    @Autowired 
    private ProdutoService service;

    @GetMapping
    public List<Produto> listar() { 
        return service.listarAtivos(); 
    }

    @GetMapping("/{id}")
    public ResponseEntity<Produto> obterPorId(@PathVariable Integer id) { 
        return ResponseEntity.ok(service.buscarPorId(id)); 
    }

    @GetMapping("/categoria/{idCategoria}")
    public List<Produto> getProdutosByCategoria(@PathVariable Integer idCategoria) { 
        return service.getProdutosPorCategoria(idCategoria); 
    }

    @PostMapping
    public Produto criar(@RequestBody Produto p) { 
        return service.salvar(p); 
    }

    @PutMapping("/{id}")
    public Produto editar(@PathVariable Integer id, @RequestBody Produto p) {
        Produto antigo = service.buscarPorId(id);
        antigo.setNome(p.getNome());
        antigo.setDescricao(p.getDescricao());
        antigo.setPreco(p.getPreco());
        antigo.setPrecoDesconto(p.getPrecoDesconto());
        antigo.setImagem(p.getImagem());
        antigo.setQtdEstoque(p.getQtdEstoque());
        antigo.setIdCategoria(p.getIdCategoria());
        antigo.setAtivo(p.getAtivo());
        return service.salvar(antigo);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Integer id) { 
        service.deletar(id); 
        return ResponseEntity.ok().build(); 
    }
}
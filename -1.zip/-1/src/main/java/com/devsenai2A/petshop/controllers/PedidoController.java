package com.devsenai2A.petshop.controllers;

import com.devsenai2A.petshop.entities.Pedido;
import com.devsenai2A.petshop.entities.ItensPedido;
import com.devsenai2A.petshop.services.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
@CrossOrigin("*")
public class PedidoController {

    @Autowired 
    private PedidoService pedidoService;

    @GetMapping("/carrinho/{usuarioId}")
    public ResponseEntity<Pedido> obterCarrinho(@PathVariable Long usuarioId) {
        try {
            Pedido pedido = pedidoService.buscarCarrinhoAberto(usuarioId);
            return ResponseEntity.ok(pedido);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/carrinho/{idPedido}/itens")
    public ResponseEntity<List<ItensPedido>> obterItensDoPedido(@PathVariable Integer idPedido) {
        List<ItensPedido> itens = pedidoService.buscarItensPorPedido(idPedido);
        return ResponseEntity.ok(itens);
    }

    @PostMapping("/carrinho/adicionar")
    public ResponseEntity<String> adicionarItem(@RequestParam Long idUsuario, @RequestParam Integer idProduto, @RequestParam Integer quantidade) {
        try {
            pedidoService.adicionarAoCarrinho(idUsuario, idProduto, quantidade);
            return ResponseEntity.ok("Item adicionado ao carrinho com sucesso!");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/carrinho/item/{idItemPedido}/pedido/{idPedido}")
    public ResponseEntity<String> removerItem(@PathVariable Integer idItemPedido, @PathVariable Integer idPedido) {
        try {
            pedidoService.removerItemDoCarrinho(idItemPedido, idPedido);
            return ResponseEntity.ok("Item removido do carrinho!");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/finalizar/{idPedido}")
    public ResponseEntity<String> finalizarPedido(@PathVariable Integer idPedido) {
        try {
            pedidoService.finalizarPedido(idPedido);
            return ResponseEntity.ok("Pedido finalizado com sucesso!");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
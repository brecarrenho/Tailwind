
package com.devsenai2A.petshop.repositories;

import com.devsenai2A.petshop.entities.ItensPedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface ItensPedidoRepository extends JpaRepository<ItensPedido, Integer> {

    Optional<ItensPedido> findByIdPedidoFkAndIdProdutoFk(Integer idPedidoFk, Integer idProdutoFk);
   
    @Query("SELECT i FROM ItensPedido i WHERE i.idPedidoFk = :idPedido AND i.idProdutoFk = :idProduto")
    Optional<ItensPedido> buscarItemExistente(@Param("idPedido") Integer idPedido, @Param("idProduto") Integer idProduto);
   
    @Query("SELECT i FROM ItensPedido i WHERE i.idPedidoFk = :idPedido")
    List<ItensPedido> findByIdPedidoFk(@Param("idPedido") Integer idPedido);
}
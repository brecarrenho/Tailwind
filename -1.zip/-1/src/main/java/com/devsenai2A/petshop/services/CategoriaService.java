package com.devsenai2A.petshop.services;

import com.devsenai2A.petshop.entities.Categoria;
import com.devsenai2A.petshop.repositories.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CategoriaService {

    @Autowired 
    private CategoriaRepository repository;

    public List<Categoria> listarTodas() { 
        return repository.findAll(); 
    }

    public List<Categoria> listarAtivas() { 
        return repository.findByAtivoTrue(); 
    }

    public Categoria salvar(Categoria c) { 
        return repository.save(c); 
    }

    public Categoria buscarPorId(Integer id) { 
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Categoria não encontrada")); 
    }

    public void deletar(Integer id) { 
        repository.deleteById(id); 
    }
}
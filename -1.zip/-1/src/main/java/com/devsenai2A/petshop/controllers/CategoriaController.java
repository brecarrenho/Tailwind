package com.devsenai2A.petshop.controllers;

import com.devsenai2A.petshop.entities.Categoria;
import com.devsenai2A.petshop.services.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/categorias")
@CrossOrigin("*")
public class CategoriaController {

    @Autowired 
    private CategoriaService service;

    @GetMapping
    public List<Categoria> listar() { 
        return service.listarAtivas(); 
    }

    @PostMapping
    public Categoria criar(@RequestBody Categoria c) { 
        return service.salvar(c); 
    }

    @PutMapping("/{id}")
    public Categoria editar(@PathVariable Integer id, @RequestBody Categoria c) {
        Categoria antiga = service.buscarPorId(id);
        antiga.setNome(c.getNome());
        antiga.setDescricao(c.getDescricao());
        antiga.setAtivo(c.getAtivo());
        return service.salvar(antiga);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Integer id) { 
        service.deletar(id); 
        return ResponseEntity.ok().build(); 
    }
}
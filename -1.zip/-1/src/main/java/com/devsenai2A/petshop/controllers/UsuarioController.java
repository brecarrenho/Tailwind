package com.devsenai2A.petshop.controllers;

import com.devsenai2A.petshop.entities.Usuario;
import com.devsenai2A.petshop.services.UsuarioService; // Importação explícita do Service
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin("*")
public class UsuarioController {

    @Autowired 
    private UsuarioService usuarioService;

    // Rota para cadastrar novos usuários (Clientes ou administradores)
    @PostMapping("/cadastro")
    public ResponseEntity<Usuario> cadastrar(@RequestBody Usuario u) { 
        Usuario novoUsuario = usuarioService.salvar(u);
        return ResponseEntity.ok(novoUsuario); 
    }

    // Rota para login e autenticação integrada ao localStorage do Frontend
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario u) {
        try {
            Usuario usuarioLogado = usuarioService.login(u.getEmail(), u.getSenha());
            return ResponseEntity.ok(usuarioLogado);
        } catch (Exception e) {
            // Retorna o texto do erro ("Senha incorreta" ou "Usuário não encontrado") com status 400
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
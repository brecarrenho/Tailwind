package com.devsenai2A.petshop.services;

import com.devsenai2A.petshop.entities.ItensPedido;
import com.devsenai2A.petshop.entities.Pedido;
import com.devsenai2A.petshop.repositories.ItensPedidoRepository;
import com.devsenai2A.petshop.repositories.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import java.util.List;

@Service
public class PedidoService {

    @Autowired 
    private PedidoRepository pedidoRepository;
    
    @Autowired 
    private ItensPedidoService itensPedidoService;
    
    @Autowired 
    private ItensPedidoRepository itensPedidoRepository;

    @Transactional
    public void adicionarAoCarrinho(Long idUsuario, Integer idProduto, Integer quantidade) {
        Pedido pedido = pedidoRepository.findByIdUsuarioFkAndStatus(idUsuario, "ABERTO")
                .orElseGet(() -> {
                    Pedido p = new Pedido();
                    p.setIdUsuarioFk(idUsuario);
                    p.setStatus("ABERTO");
                    p.setValorTotal(0.0);
                    return pedidoRepository.save(p);
                });

        // CORREÇÃO: Alterado de 'quantity' para 'quantidade' para bater com o parâmetro do método
        itensPedidoService.adicionarOuAtualizarItem(pedido.getIdPedido(), idProduto, quantidade);
        atualizarFinanceiro(pedido.getIdPedido());
    }

    @Transactional
    public void removerItemDoCarrinho(Integer idItemPedido, Integer idPedido) {
        itensPedidoService.remover(idItemPedido);
        atualizarFinanceiro(idPedido);
    }

    public void atualizarFinanceiro(Integer idPedido) {
        List<ItensPedido> itens = itensPedidoService.listarPorPedido(idPedido);
        double total = itens.stream()
                .mapToDouble(i -> i.getPrecoUnitario().doubleValue() * i.getQuantidade())
                .sum();

        Pedido pedido = pedidoRepository.findById(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido não encontrado"));
        pedido.setValorTotal(total);
        pedidoRepository.save(pedido);
    }

    public Pedido buscarCarrinhoAberto(Long idUsuario) {
        return pedidoRepository.findByIdUsuarioFkAndStatus(idUsuario, "ABERTO")
                .orElseThrow(() -> new RuntimeException("Carrinho vazio ou não encontrado"));
    }

    @Transactional
    public void finalizarPedido(Integer idPedido) {
        Pedido pedido = pedidoRepository.findById(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido não encontrado"));

        if (!"ABERTO".equals(pedido.getStatus())) {
            throw new RuntimeException("Este pedido não pode ser finalizado pois seu status é: " + pedido.getStatus());
        }

        List<ItensPedido> itens = itensPedidoService.listarPorPedido(idPedido);
        if (itens.isEmpty()) {
            throw new RuntimeException("Não é possível finalizar um pedido sem itens");
        }

        pedido.setStatus("FINALIZADO");
        pedidoRepository.save(pedido);
    }

    public List<ItensPedido> buscarItensPorPedido(Integer idPedido) {
        return itensPedidoRepository.findByIdPedidoFk(idPedido);
    }
}
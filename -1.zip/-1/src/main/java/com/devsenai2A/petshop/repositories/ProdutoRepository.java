package com.devsenai2A.petshop.repositories;

import com.devsenai2A.petshop.entities.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
    List<Produto> findByIdCategoriaAndAtivoTrue(Integer idCategoria);
    List<Produto> findByAtivoTrue();
}
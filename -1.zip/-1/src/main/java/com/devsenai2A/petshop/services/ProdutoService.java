package com.devsenai2A.petshop.services;

import com.devsenai2A.petshop.entities.Produto;
import com.devsenai2A.petshop.repositories.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProdutoService {

    @Autowired 
    private ProdutoRepository repository;

    public List<Produto> listarTodos() { 
        return repository.findAll(); 
    }

    public List<Produto> listarAtivos() { 
        return repository.findByAtivoTrue(); 
    }

    public List<Produto> getProdutosPorCategoria(Integer idCategoria) { 
        return repository.findByIdCategoriaAndAtivoTrue(idCategoria); 
    }

    public Produto buscarPorId(Integer id) { 
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Produto não encontrado")); 
    }

    public Produto salvar(Produto p) { 
        return repository.save(p); 
    }

    public void deletar(Integer id) { 
        repository.deleteById(id); 
    }
}
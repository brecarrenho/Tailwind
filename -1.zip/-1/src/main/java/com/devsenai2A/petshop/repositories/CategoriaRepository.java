package com.devsenai2A.petshop.repositories;

import com.devsenai2A.petshop.entities.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
    List<Categoria> findByAtivoTrue();
}
package com.devsenai2A.petshop.services;

import com.devsenai2A.petshop.entities.Usuario;
import com.devsenai2A.petshop.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UsuarioService {

    @Autowired 
    private UsuarioRepository repository;

    public List<Usuario> listarTodos() { 
        return repository.findAll(); 
    }

    public Usuario salvar(Usuario u) { 
        return repository.save(u); 
    }

    public Usuario login(String email, String senha) {
        Usuario u = repository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        if (!u.getSenha().equals(senha)) {
            throw new RuntimeException("Senha incorreta");
        }
        return u;
    }

    public void excluir(Long id) { 
        repository.deleteById(id); 
    }
}